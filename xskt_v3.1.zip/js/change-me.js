let generatorAutoInterval = 5000;
let manualGeneratorInterval = 1000;

let priceTypeNames = ["Special price", "First price", "Second price", "Third price", "Common price"];
let priceTypeColors = ["#ffb6c1", "#e7bd42", "#aaa9ad", "#cd7f32", "#20b2aa"];

let bannerImage = "./long-ass-dinner.png";

// fontSize = 1 equals approximately 10px
let fontSize = 3;

let audioFileToPlayWhileGenerating = new Audio("./NhacXoSo.mp3");